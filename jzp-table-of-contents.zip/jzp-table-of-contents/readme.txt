=== JZP Table of Contents ===
Contributors: jianzhanpress
Tags: table of contents, toc, contents, anchor, navigation
Requires at least: 5.0
Tested up to: 7.1
Stable tag: 1.6.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically generates a responsive Table of Contents for WordPress posts with smooth scrolling and auto-highlighting.

== Description ==

JZP Table of Contents is a lightweight WordPress plugin that automatically generates a responsive Table of Contents for your posts. It requires no shortcodes or block configuration — just activate and go.

**Features**

* **Automatic TOC generation**: Extracts H2 and H3 headings from posts and builds a clear hierarchical list.
* **Two-level nesting**: H2 headings are top-level; H3 headings nest under their parent H2.
* **Smooth scrolling**: Click a TOC item to scroll smoothly to the corresponding heading.
* **Active section highlighting**: Automatically highlights the current section as the user scrolls.
* **Multilingual titles**: Automatically switches the TOC title based on the site language.
* **Backend configurable**: Set scroll offset and hover colors in the settings page.
* **Lightweight and dependency-free**: No external libraries — friendly to performance.

**Supported languages**: Chinese, English, Japanese, Korean, German, French, Russian, Italian, Spanish, Portuguese, Arabic.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Open any post with H2 or H3 headings — the TOC will appear automatically above the content.
4. Optionally adjust the scroll offset and hover colors under "Settings → JZP TOC Settings".

== FAQ ==

= The TOC is not showing up. What should I do? =

Make sure your post contains `<h2>` or `<h3>` headings and you are viewing a single post page (not the homepage or archives).

= How do I adjust the scroll position after clicking a TOC item? =

Go to "Settings → JZP TOC Settings" and change the "Scroll offset (px)". If your theme has a fixed navigation bar, set it to the navbar height + 20px.

= What colors can I customize? =

You can customize the hover background color and hover text color. For further adjustments, use Additional CSS in the Customizer to override classes like `.jzp-toc-link`.

== Changelog ==

= 1.6.2 =
* Added tab navigation in the settings page (Basic Settings / Plugin Info / Help).
* Built-in multilingual TOC titles.
* Code quality improvements.

= 1.4.0 =
* Added custom hover color options.
* Added scroll offset setting.

= 1.0.0 =
* Initial release.
