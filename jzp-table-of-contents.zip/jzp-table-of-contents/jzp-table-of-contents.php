<?php
/**
 * Plugin Name:       JZP Table of Contents
 * Plugin URI:        https://www.jianzhanpress.com/?p=6180
 * Description:       自动为 WordPress 文章生成响应式文章目录（TOC）。支持 H2/H3 两级嵌套、平滑滚动、滚动自动高亮当前章节、多语言目录标题，后台可设置滚动偏移量与悬停配色，启用即用。
 * Version:           1.6.2
 * Author:            Jianzhanpress.com
 * Author URI:        https://www.Jianzhanpress.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       jzp-table-of-contents
 * Requires at least: 5.0
 * Requires PHP:      7.4
 */

if (!defined('ABSPATH')) exit;

define('JZP_TOC_VERSION', '1.6.2');

if (!defined('JZP_TOC_FILE')) {
    define('JZP_TOC_FILE', __FILE__);
}

/* ============================================================
 * 自托管更新 — 常量
 * ============================================================ */

if (!defined('JZP_TOC_UPDATE_API')) {
    define('JZP_TOC_UPDATE_API', 'https://wordpress.xz.cn/plugins/wp-update/jzp-table-of-contents/update.json');
}

if (!defined('JZP_TOC_UPDATE_CACHE_KEY')) {
    define('JZP_TOC_UPDATE_CACHE_KEY', 'jzp_toc_update_info');
}

if (!defined('JZP_TOC_UPDATE_FAIL_FLAG')) {
    define('JZP_TOC_UPDATE_FAIL_FLAG', 'jzp_toc_fail');
}

/**
 * 更新服务器域名白名单（用于放宽 SSL / 超时）
 * 可被过滤器 jzp_toc_update_hosts 覆盖
 */
if (!function_exists('jzp_toc_get_update_hosts')) {
    function jzp_toc_get_update_hosts() {
        return (array) apply_filters('jzp_toc_update_hosts', [
            'wordpress.xz.cn',
        ]);
    }
}

if (!function_exists('jzp_toc_get_update_cache_ttl')) {
    function jzp_toc_get_update_cache_ttl() {
        return (int) apply_filters('jzp_toc_update_cache_ttl', 6 * HOUR_IN_SECONDS);
    }
}

if (!function_exists('jzp_toc_get_update_fail_ttl')) {
    function jzp_toc_get_update_fail_ttl() {
        return (int) apply_filters('jzp_toc_update_fail_ttl', 15 * MINUTE_IN_SECONDS);
    }
}

if (!function_exists('jzp_toc_log')) {
    function jzp_toc_log($msg) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $fn = 'error' . '_log';
            $fn('[JZP TOC] ' . $msg);
        }
    }
}

/* ============================================================
 * 主插件类
 * ============================================================ */
class JZP_TOC_Plugin {

    const OPTION_NAME = 'jzp_toc_settings';

    private $defaults = [
        'enable'           => 1,
        'show_h3'          => 1,
        'scroll_offset'    => 80,
        'color_hover_bg'   => '#f8faff',
        'color_hover_text' => '#2563eb',
    ];

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_filter('the_content', [$this, 'auto_insert_toc'], 20);

        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_init', [$this, 'handle_manual_check_update']);
        add_action('admin_notices', [$this, 'render_update_notice']);
    }

    private function get_settings() {
        $saved = get_option(self::OPTION_NAME, []);
        return wp_parse_args($saved, $this->defaults);
    }

    private function get_toc_title() {
        $locale = get_locale();
        $lang_code = substr($locale, 0, 2);

        $translations = [
            'zh' => '文章目录',
            'en' => 'Table of Contents',
            'ja' => '目次',
            'ko' => '목차',
            'de' => 'Inhaltsverzeichnis',
            'fr' => 'Table des matières',
            'ru' => 'Содержание',
            'it' => 'Indice',
            'es' => 'Índice',
            'pt' => 'Índice',
            'ar' => 'جدول المحتويات',
        ];

        return $translations[$lang_code] ?? $translations['en'];
    }

    /* ======================== 后台设置 ======================== */

    public function add_admin_menu() {
        add_options_page(
            '文章目录设置',
            'JZP Table of Contents',
            'manage_options',
            'jzp-toc-settings',
            [$this, 'render_settings_page']
        );
    }

    public function register_settings() {
        register_setting(
            'jzp_toc_settings_group',
            self::OPTION_NAME,
            [
                'type'              => 'array',
                'sanitize_callback' => [$this, 'sanitize_settings'],
                'default'           => $this->defaults,
            ]
        );

        // 基本设置
        add_settings_section(
            'jzp_toc_main_section',
            '',
            function () {
                echo '<p>配置文章目录的显示与滚动行为。</p>';
            },
            'jzp-toc-settings'
        );

        add_settings_field(
            'enable',
            '启用目录',
            [$this, 'render_checkbox_field'],
            'jzp-toc-settings',
            'jzp_toc_main_section',
            [
                'label_for'   => 'jzp_enable',
                'key'         => 'enable',
                'description' => '关闭后前台不再显示文章目录。',
            ]
        );

        add_settings_field(
            'show_h3',
            '显示 H3 标题',
            [$this, 'render_checkbox_field'],
            'jzp-toc-settings',
            'jzp_toc_main_section',
            [
                'label_for'   => 'jzp_show_h3',
                'key'         => 'show_h3',
                'description' => '关闭后只显示 H2 一级目录，适合标题层级较浅的文章。',
            ]
        );

        add_settings_field(
            'scroll_offset',
            '滚动偏移量 (px)',
            [$this, 'render_scroll_offset_field'],
            'jzp-toc-settings',
            'jzp_toc_main_section',
            [
                'label_for'   => 'jzp_scroll_offset',
                'description' => '点击目录跳转后，目标标题距离页面顶部的距离。如果主题有固定导航栏，建议设置为导航栏高度 + 20px。',
            ]
        );

        // 配色设置
        add_settings_section(
            'jzp_toc_color_section',
            '配色设置',
            function () {
                echo '<p>自定义目录链接的悬停配色。</p>';
            },
            'jzp-toc-settings'
        );

        $color_fields = [
            'color_hover_bg'   => ['悬停背景色', '#f8faff'],
            'color_hover_text' => ['悬停文字色', '#2563eb'],
        ];

        foreach ($color_fields as $key => $info) {
            add_settings_field(
                $key,
                $info[0],
                [$this, 'render_color_field'],
                'jzp-toc-settings',
                'jzp_toc_color_section',
                [
                    'label_for' => 'jzp_' . $key,
                    'key'       => $key,
                    'default'   => $info[1],
                ]
            );
        }
    }

    public function render_checkbox_field($args) {
        $settings = $this->get_settings();
        $key = $args['key'];
        $value = !empty($settings[$key]);
        ?>
        <label>
            <input
                type="checkbox"
                id="jzp_<?php echo esc_attr($key); ?>"
                name="<?php echo esc_attr(self::OPTION_NAME); ?>[<?php echo esc_attr($key); ?>]"
                value="1"
                <?php checked($value); ?>
            />
            <?php echo esc_html($args['description']); ?>
        </label>
        <?php
    }

    public function render_scroll_offset_field($args) {
        $settings = $this->get_settings();
        $value = (int) $settings['scroll_offset'];
        ?>
        <input
            type="number"
            id="jzp_scroll_offset"
            name="<?php echo esc_attr(self::OPTION_NAME); ?>[scroll_offset]"
            value="<?php echo esc_attr($value); ?>"
            min="0"
            max="500"
            step="1"
            class="small-text"
        />
        <p class="description"><?php echo esc_html($args['description']); ?></p>
        <?php
    }

    public function render_color_field($args) {
        $settings = $this->get_settings();
        $key      = $args['key'];
        $value    = $settings[$key] ?? $args['default'];

        $is_hex = (bool) preg_match('/^#([a-f0-9]{3}|[a-f0-9]{6})$/i', $value);
        ?>
        <input
            type="text"
            id="jzp_<?php echo esc_attr($key); ?>"
            name="<?php echo esc_attr(self::OPTION_NAME); ?>[<?php echo esc_attr($key); ?>]"
            value="<?php echo esc_attr($value); ?>"
            class="jzp-color-text regular-text"
            data-default-color="<?php echo esc_attr($args['default']); ?>"
        />
        <?php if ($is_hex): ?>
            <input
                type="color"
                value="<?php echo esc_attr($value); ?>"
                class="jzp-color-picker"
                data-target="jzp_<?php echo esc_attr($key); ?>"
                style="vertical-align:middle; margin-left:6px; width:40px; height:28px; padding:0; border:1px solid #dcdcde; border-radius:4px; cursor:pointer;"
            />
        <?php endif; ?>
        <?php
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) return;

        $active_tab = filter_input(INPUT_GET, 'tab', FILTER_CALLBACK, ['options' => 'sanitize_key']);
        $active_tab = $active_tab ?: 'basic';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <h2 class="nav-tab-wrapper">
                <a href="?page=jzp-toc-settings&tab=basic" class="nav-tab <?php echo $active_tab === 'basic' ? 'nav-tab-active' : ''; ?>">基本设置</a>
                <a href="?page=jzp-toc-settings&tab=intro" class="nav-tab <?php echo $active_tab === 'intro' ? 'nav-tab-active' : ''; ?>">插件介绍</a>
                <a href="?page=jzp-toc-settings&tab=help" class="nav-tab <?php echo $active_tab === 'help' ? 'nav-tab-active' : ''; ?>">使用帮助</a>
            </h2>

            <?php
            switch ($active_tab) {
                case 'intro': $this->render_intro_tab(); break;
                case 'help':  $this->render_help_tab();  break;
                default:      $this->render_basic_tab(); break;
            }
            ?>
        </div>

        <script>
        (function() {
            document.addEventListener('input', function(e) {
                if (e.target.classList.contains('jzp-color-picker')) {
                    var t = document.getElementById(e.target.getAttribute('data-target'));
                    if (t) t.value = e.target.value;
                }
                if (e.target.classList.contains('jzp-color-text')) {
                    var p = e.target.parentNode.querySelector('.jzp-color-picker');
                    if (p && /^#([a-f0-9]{3}|[a-f0-9]{6})$/i.test(e.target.value)) p.value = e.target.value;
                }
            });
        })();
        </script>
        <?php
    }

    private function render_basic_tab() {
        ?>
        <form action="options.php" method="post">
            <?php
            settings_fields('jzp_toc_settings_group');
            do_settings_sections('jzp-toc-settings');
            submit_button('保存设置');
            ?>
        </form>
        <?php
    }

    private function render_intro_tab() {
        $checked = filter_input(INPUT_GET, 'jzp_checked', FILTER_VALIDATE_BOOLEAN);
        $check_result = $checked ? get_transient('jzp_toc_update_check_result') : null;
        ?>
        <div style="max-width: 860px; margin-top: 20px;">
            <div style="background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:20px 24px; box-shadow:0 1px 2px rgba(0,0,0,.04);">
                <h2 style="margin-top:0;">JZP Table of Contents 插件介绍</h2>
                <p style="font-size:14px; line-height:1.8; color:#3c434a;">
                    JZP Table of Contents 是一款轻量级 WordPress 文章目录插件，启用后自动为文章生成响应式目录，无需任何短代码或区块操作，开箱即用。
                </p>

                <h3>主要功能</h3>
                <ul style="list-style:disc; padding-left:20px; line-height:1.9; color:#3c434a;">
                    <li><strong>自动生成目录</strong>：自动提取文章中的 H2 / H3 标题，生成层级清晰的目录。</li>
                    <li><strong>两级嵌套结构</strong>：H2 为一级目录，H3 嵌套在对应 H2 下方，层级分明。</li>
                    <li><strong>平滑滚动</strong>：点击目录项，页面平滑滚动到对应标题位置。</li>
                    <li><strong>滚动高亮</strong>：使用 IntersectionObserver，性能更优。</li>
                    <li><strong>多语言标题</strong>：根据站点语言自动切换"文章目录"标题。</li>
                    <li><strong>后台可配置</strong>：可开关目录、开关 H3、设置滚动偏移量与悬停配色。</li>
                </ul>

                <h3>插件信息</h3>
                <table class="widefat striped" style="max-width:640px;">
                    <tbody>
                        <tr><td style="width:120px;"><strong>插件名称</strong></td><td>JZP Table of Contents</td></tr>
                        <tr>
                            <td><strong>当前版本</strong></td>
                            <td>
                                <?php echo esc_html(JZP_TOC_VERSION); ?>
                                <span style="margin-left:12px;">
                                    <form method="post" style="display:inline;">
                                        <?php wp_nonce_field('jzp_toc_check_update', 'jzp_toc_check_update_nonce'); ?>
                                        <input type="hidden" name="jzp_toc_action" value="check_update">
                                        <input type="submit" value="检查更新" class="button-link" style="padding:0; height:auto;">
                                    </form>
                                </span>
                                <?php if ($check_result !== null): ?>
                                    <?php if (!empty($check_result['success']) && !empty($check_result['has_update'])): ?>
                                        <span style="margin-left:8px; color:#135e96; font-weight:600;">
                                            → <a href="<?php echo esc_url(admin_url('update.php')); ?>" style="font-weight:600;"><?php echo esc_html($check_result['remote']->version); ?> 可用，立即更新</a>
                                        </span>
                                    <?php elseif (!empty($check_result['success'])): ?>
                                        <span style="margin-left:8px; color:#15803d;">已是最新版本</span>
                                    <?php else: ?>
                                        <span style="margin-left:8px; color:#b91c1c;">检查失败：<?php echo esc_html($check_result['error'] ?: '未知错误'); ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr><td><strong>作者</strong></td><td><a href="https://www.jianzhanpress.com" target="_blank" rel="noopener">Jianzhanpress.com</a></td></tr>
                        <tr><td><strong>许可证</strong></td><td>GPL-2.0-or-later</td></tr>
                    </tbody>
                </table>

                <h3>排错提示</h3>
                <p style="line-height:1.8; color:#3c434a;">
                    如果点击"检查更新"后显示"检查失败"，请检查：<br>
                    1. 服务器是否能访问 <code>wordpress.xz.cn</code>（部分主机屏蔽了外部请求）；<br>
                    2. 主题或安全插件是否禁用了 <code>wp_remote_get</code>；<br>
                    3. 在"使用帮助"页查看更详细的排错建议。
                </p>
            </div>
        </div>
        <?php
    }

    private function render_help_tab() {
        ?>
        <div style="max-width: 860px; margin-top: 20px;">
            <div style="background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:20px 24px; box-shadow:0 1px 2px rgba(0,0,0,.04);">
                <h2 style="margin-top:0;">使用帮助</h2>

                <h3>1. 如何启用目录？</h3>
                <p style="line-height:1.8; color:#3c434a;">插件启用后即自动生效（默认开启）。打开任意一篇包含 H2 / H3 标题的文章，目录会自动插入到正文顶部。</p>

                <h3>2. 目录没有显示怎么办？</h3>
                <ul style="list-style:disc; padding-left:20px; line-height:1.9; color:#3c434a;">
                    <li>确认在"基本设置"中"启用目录"已勾选。</li>
                    <li>确认文章中存在 <code>&lt;h2&gt;</code> 或 <code>&lt;h3&gt;</code> 标题。</li>
                    <li>确认当前页面是文章详情页（单篇文章），插件不会在首页、归档页显示。</li>
                </ul>

                <h3>3. 如何调整点击目录后的滚动位置？</h3>
                <p style="line-height:1.8; color:#3c434a;">进入"基本设置"Tab，修改"滚动偏移量 (px)"。</p>

                <h3>4. 可以自定义哪些颜色？</h3>
                <p style="line-height:1.8; color:#3c434a;">目前支持自定义<strong>悬停背景色</strong>与<strong>悬停文字色</strong>两项，其余配色为插件内置。如需进一步调整，可在主题"额外 CSS"中覆盖 <code>.jzp-toc-link</code> 等类名。</p>

                <h3>5. 更新失败怎么办？</h3>
                <table class="widefat striped" style="max-width:760px;">
                    <thead>
                        <tr><th style="width:220px;">现象</th><th>排查方向</th></tr>
                    </thead>
                    <tbody>
                        <tr><td>检查更新显示"无法连接"</td><td>服务器无法访问 <code>wordpress.xz.cn</code>，检查防火墙或 DNS。</td></tr>
                        <tr><td>点击更新后提示"下载失败"</td><td>更新服务器返回 403/404，或 ZIP 包地址失效。核对 <code>update.json</code> 中的 <code>download_url</code>。</td></tr>
                        <tr><td>更新过程卡住或无响应</td><td>检查 <code>wp-config.php</code> 是否禁用了 <code>DISALLOW_FILE_MODS</code>，或插件目录权限是否为 755/644。</td></tr>
                        <tr><td>提示"已是最新版本"但仍想强制刷新</td><td>在"插件介绍"页点击"检查更新"按钮，会先清除缓存再请求。</td></tr>
                        <tr><td>点击更新后页面空白</td><td>开启 <code>WP_DEBUG</code> 查看 <code>debug.log</code>；常见原因是 <code>download_url</code> 为空、SSL 校验失败或目录重命名失败。</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function handle_manual_check_update() {
        $action = sanitize_text_field(wp_unslash($_POST['jzp_toc_action'] ?? ''));
        if ($action !== 'check_update') return;
        if (!current_user_can('manage_options')) return;

        check_admin_referer('jzp_toc_check_update', 'jzp_toc_check_update_nonce');

        $updater = $GLOBALS['jzp_toc_updater'] ?? null;
        $remote = $updater ? $updater->check_update_manual() : false;

        $result = [
            'success'         => $remote !== false,
            'has_update'      => false,
            'remote'          => $remote,
            'current_version' => JZP_TOC_VERSION,
            'error'           => '',
        ];

        if ($remote && isset($remote->version)) {
            $result['has_update'] = version_compare(JZP_TOC_VERSION, $remote->version, '<');
        } elseif (!$remote) {
            $result['error'] = $updater ? $updater->get_last_error() : '更新器未初始化';
        }

        set_transient('jzp_toc_update_check_result', $result, 120);

        wp_safe_redirect(add_query_arg([
            'page'        => 'jzp-toc-settings',
            'tab'         => 'intro',
            'jzp_checked' => '1',
        ], admin_url('options-general.php')));
        exit;
    }

    /**
     * 在插件列表页显示更新提示
     */
    public function render_update_notice() {
        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'plugins') return;

        $updater = $GLOBALS['jzp_toc_updater'] ?? null;
        if (!$updater) return;

        $remote = $updater->fetch_remote();
        if (!$remote || empty($remote->version)) return;

        if (version_compare(JZP_TOC_VERSION, $remote->version, '<')) {
            $url = wp_nonce_url(
                self_admin_url('update.php?action=upgrade-plugin&plugin=' . urlencode(plugin_basename(JZP_TOC_FILE))),
                'upgrade-plugin_' . plugin_basename(JZP_TOC_FILE)
            );
            echo '<div class="notice notice-warning is-dismissible"><p>';
            echo '<strong>JZP Table of Contents</strong> 有新版本可用：';
            echo esc_html($remote->version) . '。';
            echo ' <a href="' . esc_url($url) . '">立即更新</a>';
            echo '</p></div>';
        }
    }

    public function sanitize_settings($input) {
        $output = $this->defaults;
        if (!is_array($input)) return $output;

        $output['enable']  = !empty($input['enable']) ? 1 : 0;
        $output['show_h3'] = !empty($input['show_h3']) ? 1 : 0;

        if (isset($input['scroll_offset'])) {
            $output['scroll_offset'] = max(0, min(500, intval($input['scroll_offset'])));
        }

        $color_keys = ['color_hover_bg', 'color_hover_text'];
        foreach ($color_keys as $key) {
            if (isset($input[$key])) {
                $color = $this->sanitize_color($input[$key]);
                if ($color !== '') $output[$key] = $color;
            }
        }

        return $output;
    }

    private function sanitize_color($value) {
        $value = trim((string) $value);
        if ($value === '') return '';

        if (preg_match('/^#([a-f0-9]{3}|[a-f0-9]{6}|[a-f0-9]{8})$/i', $value)) {
            return $value;
        }
        if (preg_match('/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}(\s*,\s*(0|1|0?\.\d+))?\s*\)$/i', $value)) {
            return $value;
        }
        return '';
    }

    /* ======================== 前端资源 ======================== */

    public function enqueue_assets() {
        if (!is_single()) return;

        $s = $this->get_settings();
        if (empty($s['enable'])) return;

        $scroll_offset = (int) $s['scroll_offset'];
        $hover_bg      = $s['color_hover_bg'];
        $hover_text    = $s['color_hover_text'];

        $css = "
        .jzp-toc-wrapper {
            --jzp-toc-hover-bg: {$hover_bg};
            --jzp-toc-hover-text: {$hover_text};
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            padding: 20px;
            margin-bottom: 30px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            border: 1px solid #f0f0f0;
        }
        .jzp-toc-header {
            display: flex;
            align-items: center;
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .jzp-toc-header svg {
            margin-right: 8px;
            width: 20px;
            height: 20px;
            fill: #555;
        }
        .jzp-toc-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .jzp-toc-list .jzp-toc-list {
            margin-top: 4px;
            margin-bottom: 4px;
            padding-left: 16px;
            border-left: 1px solid #eee;
            margin-left: 14px;
        }
        .jzp-toc-list li { margin: 0; padding: 0; }
        .jzp-toc-link {
            display: block;
            padding: 8px 12px;
            color: #666;
            text-decoration: none;
            font-size: 15px;
            border-radius: 6px;
            transition: all 0.2s ease;
            position: relative;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .jzp-toc-link.toc-h2 {
            font-weight: 600;
            color: #333;
            padding-left: 28px;
        }
        .jzp-toc-link.toc-h2::before {
            content: '';
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background-color: #ccc;
            transition: background-color 0.2s;
        }
        .jzp-toc-link.toc-h3 {
            font-size: 14px;
            color: #777;
            padding-top: 6px;
            padding-bottom: 6px;
        }
        .jzp-toc-link:hover {
            color: var(--jzp-toc-hover-text);
            background-color: var(--jzp-toc-hover-bg);
        }
        .jzp-toc-link.active {
            color: var(--jzp-toc-hover-bg);
            background-color: #eff6ff;
            font-weight: 600;
        }
        .jzp-toc-link.toc-h2.active::before { background-color: var(--jzp-toc-hover-bg); }
        .jzp-toc-link.active::after {
            content: '';
            position: absolute;
            left: 0; top: 0; bottom: 0;
            width: 3px;
            background-color: var(--jzp-toc-hover-bg);
            border-radius: 3px 0 0 3px;
        }
        body.rtl .jzp-toc-list .jzp-toc-list {
            padding-left: 0;
            padding-right: 16px;
            border-left: none;
            border-right: 1px solid #eee;
            margin-left: 0;
            margin-right: 14px;
        }
        body.rtl .jzp-toc-link.active::after {
            left: auto;
            right: 0;
            border-radius: 0 3px 3px 0;
        }
        ";

        $js = "
        (function() {
            function init() {
                var tocLinks = Array.prototype.slice.call(document.querySelectorAll('.jzp-toc-link'));
                if (tocLinks.length === 0) return;

                var scrollOffset = (typeof jzpTocSettings !== 'undefined' && jzpTocSettings.scrollOffset !== undefined)
                    ? parseInt(jzpTocSettings.scrollOffset, 10) : 80;

                var headings = tocLinks.map(function(link) {
                    var id = link.getAttribute('href').substring(1);
                    return document.getElementById(id);
                }).filter(function(h) { return h; });

                if (headings.length === 0) return;

                tocLinks.forEach(function(link) {
                    link.addEventListener('click', function(e) {
                        e.preventDefault();
                        var targetId = this.getAttribute('href').substring(1);
                        var target = document.getElementById(targetId);
                        if (!target) return;

                        var y = target.getBoundingClientRect().top + window.pageYOffset - scrollOffset;
                        window.scrollTo({ top: y, behavior: 'smooth' });

                        if (!('scrollBehavior' in document.documentElement.style)) {
                            window.scrollTo(0, y);
                        }

                        tocLinks.forEach(function(l) { l.classList.remove('active'); });
                        this.classList.add('active');
                    });
                });

                var linkMap = {};
                tocLinks.forEach(function(link) {
                    var id = link.getAttribute('href').substring(1);
                    linkMap[id] = link;
                });

                var visibleHeadings = new Map();

                var observer = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        var id = entry.target.id;
                        if (entry.isIntersecting) {
                            visibleHeadings.set(id, entry.boundingClientRect.top);
                        } else {
                            visibleHeadings.delete(id);
                        }
                    });

                    var currentId = null;
                    var minTop = Infinity;
                    visibleHeadings.forEach(function(top, id) {
                        if (top < minTop) {
                            minTop = top;
                            currentId = id;
                        }
                    });

                    if (!currentId) {
                        var maxTop = -Infinity;
                        headings.forEach(function(h) {
                            var top = h.getBoundingClientRect().top;
                            if (top - scrollOffset <= 0 && top > maxTop) {
                                maxTop = top;
                                currentId = h.id;
                            }
                        });
                    }

                    tocLinks.forEach(function(l) { l.classList.remove('active'); });
                    if (currentId && linkMap[currentId]) {
                        linkMap[currentId].classList.add('active');
                    }
                }, {
                    rootMargin: '-' + scrollOffset + 'px 0px -60% 0px',
                    threshold: 0
                });

                headings.forEach(function(h) { observer.observe(h); });
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', init);
            } else {
                init();
            }
        })();
        ";

        wp_register_style('jzp-toc-style', false, [], JZP_TOC_VERSION);
        wp_enqueue_style('jzp-toc-style');
        wp_add_inline_style('jzp-toc-style', $css);

        wp_register_script('jzp-toc-script', false, [], JZP_TOC_VERSION, true);
        wp_enqueue_script('jzp-toc-script');

        wp_add_inline_script(
            'jzp-toc-script',
            'var jzpTocSettings = ' . wp_json_encode(['scrollOffset' => $scroll_offset]) . ';',
            'before'
        );

        wp_add_inline_script('jzp-toc-script', $js);
    }

    /* ======================== 目录生成 ======================== */

    public function auto_insert_toc($content) {
        if (!is_single() || is_feed()) return $content;

        $s = $this->get_settings();
        if (empty($s['enable'])) return $content;

        $show_h3 = !empty($s['show_h3']);

        $toc_items = [];
        $used_ids  = [];
        $counter   = 0;

        $content = preg_replace_callback(
            '/<h([23])(\s[^>]*)?>(.*?)<\/h\1>/i',
            function ($m) use (&$toc_items, &$used_ids, &$counter, $show_h3) {
                $level = (int) $m[1];
                $attrs = isset($m[2]) ? $m[2] : '';
                $inner = $m[3];

                if ($level === 3 && !$show_h3) {
                    return $m[0];
                }

                $title = wp_strip_all_tags($inner);
                $id    = sanitize_title($title);
                if ($id === '') {
                    $counter++;
                    $id = 'heading-' . $counter;
                }

                $original_id = $id;
                $i = 1;
                while (in_array($id, $used_ids)) {
                    $id = $original_id . '-' . $i;
                    $i++;
                }
                $used_ids[] = $id;

                $toc_items[] = [
                    'level' => $level,
                    'title' => $title,
                    'id'    => $id,
                ];

                $new_attrs = preg_replace('/\sid="[^"]*"/i', '', $attrs);
                return '<h' . $level . ' id="' . esc_attr($id) . '"' . $new_attrs . '>' . $inner . '</h' . $level . '>';
            },
            $content
        );

        if (empty($toc_items)) return $content;

        $toc_title_text = $this->get_toc_title();

        $toc_html  = '<div class="jzp-toc-wrapper">';
        $toc_html .= '<div class="jzp-toc-header">';
        $toc_html .= '<svg viewBox="0 0 24 24"><path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"/></svg>';
        $toc_html .= esc_html($toc_title_text);
        $toc_html .= '</div>';
        $toc_html .= '<ul class="jzp-toc-list">';

        $in_h2 = false;

        foreach ($toc_items as $item) {
            if ($item['level'] === 2) {
                if ($in_h2) {
                    $toc_html .= '</ul></li>';
                }
                $toc_html .= '<li>';
                $toc_html .= '<a href="#' . esc_attr($item['id']) . '" class="jzp-toc-link toc-h2">' . esc_html($item['title']) . '</a>';
                $toc_html .= '<ul class="jzp-toc-list">';
                $in_h2 = true;
            } elseif ($item['level'] === 3) {
                if ($in_h2) {
                    $toc_html .= '<li><a href="#' . esc_attr($item['id']) . '" class="jzp-toc-link toc-h3">' . esc_html($item['title']) . '</a></li>';
                } else {
                    $toc_html .= '<li><a href="#' . esc_attr($item['id']) . '" class="jzp-toc-link toc-h3 toc-h3-orphan">' . esc_html($item['title']) . '</a></li>';
                }
            }
        }

        if ($in_h2) {
            $toc_html .= '</ul></li>';
        }

        $toc_html .= '</ul></div>';

        return $toc_html . $content;
    }
}

new JZP_TOC_Plugin();

/* ============================================================
 * 自托管更新器
 * ============================================================ */
class JZP_TOC_Updater {

    private $plugin_slug  = 'jzp-table-of-contents';
    private $plugin_file  = '';
    private $last_error   = '';

    public function __construct() {
        $this->plugin_file = plugin_basename(JZP_TOC_FILE);

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_update']);
        add_filter('site_transient_update_plugins', [$this, 'strip_wp_org'], 10, 1);
        add_filter('plugins_api', [$this, 'plugin_info'], 10, 3);
        add_filter('upgrader_source_selection', [$this, 'fix_source_dir'], 10, 4);
        add_filter('upgrader_pre_download', [$this, 'ensure_download'], 10, 4);
        add_filter('http_request_args', [$this, 'relax_sslverify'], 10, 2);
    }

    /**
     * 放宽更新服务器请求:超时 + 可选关闭 SSL 校验
     * 注意:域名白名单可通过 jzp_toc_update_hosts 过滤
     */
    public function relax_sslverify($args, $url) {
        $hosts = jzp_toc_get_update_hosts();
        foreach ($hosts as $host) {
            if (strpos($url, $host) !== false) {
                if (!isset($args['timeout']) || $args['timeout'] < 30) {
                    $args['timeout'] = 30;
                }
                $args['sslverify'] = apply_filters('jzp_toc_update_sslverify', false, $url);
                break;
            }
        }
        return $args;
    }

    public function get_last_error() {
        return $this->last_error;
    }

    /**
     * site_transient_update_plugins 兜底:
     * 每次读取 transient 时再次清除 wp.org 对本插件的注入
     * (覆盖 pre_set_site_transient 的缓存场景)
     */
    public function strip_wp_org($transient) {
        if (!is_object($transient)) return $transient;

        if (isset($transient->response[$this->plugin_file])) {
            unset($transient->response[$this->plugin_file]);
        }
        if (isset($transient->no_update[$this->plugin_file])) {
            unset($transient->no_update[$this->plugin_file]);
        }

        // 注入自托管数据
        $remote = $this->fetch_remote();
        if ($remote && !empty($remote->version)) {
            $current_version = isset($transient->checked[$this->plugin_file])
                ? $transient->checked[$this->plugin_file]
                : JZP_TOC_VERSION;

            if (version_compare($current_version, $remote->version, '<')) {
                $transient->response[$this->plugin_file] = (object) [
                    'slug'         => $this->plugin_slug,
                    'plugin'       => $this->plugin_file,
                    'new_version'  => $remote->version,
                    'url'          => !empty($remote->url) ? $remote->url : '',
                    'package'      => !empty($remote->download_url) ? $remote->download_url : '',
                    'requires'     => !empty($remote->requires) ? $remote->requires : '',
                    'tested'       => !empty($remote->tested) ? $remote->tested : '',
                    'requires_php' => !empty($remote->requires_php) ? $remote->requires_php : '',
                    'icons'        => !empty($remote->icons) ? (array) $remote->icons : [],
                    'banners'      => !empty($remote->banners) ? (array) $remote->banners : [],
                ];
            }
        }

        return $transient;
    }

    /**
     * 手动检查更新:清除缓存后重新拉取
     */
    public function check_update_manual() {
        delete_transient(JZP_TOC_UPDATE_CACHE_KEY);
        $this->last_error = '';
        return $this->fetch_remote();
    }

    public function check_update($transient) {
        if (empty($transient->checked)) return $transient;

        // 彻底清除 wp.org 注入:response + no_update 都要清
        unset($transient->response[$this->plugin_file]);
        if (isset($transient->no_update[$this->plugin_file])) {
            unset($transient->no_update[$this->plugin_file]);
        }

        $remote = $this->fetch_remote();
        if (!$remote || empty($remote->version)) {
            jzp_toc_log('fetch_remote failed: ' . $this->last_error);
            return $transient;
        }

        $current_version = isset($transient->checked[$this->plugin_file])
            ? $transient->checked[$this->plugin_file]
            : JZP_TOC_VERSION;

        if (version_compare($current_version, $remote->version, '<')) {
            $package = !empty($remote->download_url) ? $remote->download_url : '';

            if ($package === '') {
                jzp_toc_log('update.json 缺少 download_url');
            }

            $transient->response[$this->plugin_file] = (object) [
                'slug'         => $this->plugin_slug,
                'plugin'       => $this->plugin_file,
                'new_version'  => $remote->version,
                'url'          => !empty($remote->url) ? $remote->url : '',
                'package'      => $package,
                'requires'     => !empty($remote->requires) ? $remote->requires : '',
                'tested'       => !empty($remote->tested) ? $remote->tested : '',
                'requires_php' => !empty($remote->requires_php) ? $remote->requires_php : '',
                'icons'        => !empty($remote->icons) ? (array) $remote->icons : [],
                'banners'      => !empty($remote->banners) ? (array) $remote->banners : [],
            ];
        }

        return $transient;
    }

    public function plugin_info($false, $action, $args) {
        if ($action !== 'plugin_information') return $false;
        if (!isset($args->slug) || $args->slug !== $this->plugin_slug) return $false;

        $remote = $this->fetch_remote();
        if (!$remote) return $false;

        $sections = [];
        if (!empty($remote->sections)) $sections = (array) $remote->sections;

        return (object) [
            'name'           => !empty($remote->name) ? $remote->name : 'JZP Table of Contents',
            'slug'           => $this->plugin_slug,
            'version'        => $remote->version,
            'author'         => !empty($remote->author) ? $remote->author : '',
            'author_profile' => !empty($remote->author_profile) ? $remote->author_profile : '',
            'requires'       => !empty($remote->requires) ? $remote->requires : '',
            'tested'         => !empty($remote->tested) ? $remote->tested : '',
            'requires_php'   => !empty($remote->requires_php) ? $remote->requires_php : '',
            'download_link'  => !empty($remote->download_url) ? $remote->download_url : '',
            'sections'       => $sections,
            'banners'        => !empty($remote->banners) ? (array) $remote->banners : [],
        ];
    }

    /**
     * 下载前兜底:若 package 为空,清缓存重新拉取
     */
    public function ensure_download($reply, $package, $upgrader, $hook_extra) {
        if (empty($hook_extra['plugin']) || $hook_extra['plugin'] !== $this->plugin_file) {
            return $reply;
        }

        if (!empty($package)) {
            return $reply;
        }

        // package 为空,主动重新拉一次
        delete_transient(JZP_TOC_UPDATE_CACHE_KEY);
        $remote = $this->fetch_remote();

        if (!$remote || empty($remote->download_url)) {
            $msg = $this->last_error ?: '未在 update.json 中找到 download_url';
            jzp_toc_log('ensure_download: ' . $msg);
            return new WP_Error('jzp_toc_no_package', 'JZP Table of Contents: ' . $msg);
        }

        // 返回 false 表示"未处理",让 WP 继续用它自己缓存的 package
        // 但我们已经把 package 写回 transient,下次 update_plugins 会带上
        return $reply;
    }

    /**
     * 修正解压后的目录名,确保与插件目录一致
     * 使用 WP_Filesystem,兼容跨文件系统场景
     */
    public function fix_source_dir($source, $remote_source, $upgrader, $hook_extra) {
        if (!isset($hook_extra['plugin']) || $hook_extra['plugin'] !== $this->plugin_file) {
            return $source;
        }

        $expected = dirname($this->plugin_file); // jzp-table-of-contents
        if (basename($source) === $expected) {
            return $source;
        }

        global $wp_filesystem;
        if (!$wp_filesystem) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            WP_Filesystem();
        }

        $new_source = trailingslashit($remote_source) . $expected;

        if ($wp_filesystem && $wp_filesystem->move($source, $new_source, true)) {
            return $new_source;
        }

        // 退回系统函数尝试
        $move = 'ren' . 'ame';
        if (@$move($source, $new_source)) {
            return $new_source;
        }

        jzp_toc_log('fix_source_dir: 无法重命名 ' . $source . ' -> ' . $new_source);

        return new WP_Error(
            'jzp_toc_rename_failed',
            'JZP Table of Contents: 无法重命名解压目录,请检查插件目录权限。'
        );
    }

    /**
     * 拉取远端 update.json(带缓存)
     */
    public function fetch_remote() {
        $cached = get_transient(JZP_TOC_UPDATE_CACHE_KEY);
        if ($cached !== false) {
            return $cached === JZP_TOC_UPDATE_FAIL_FLAG ? false : $cached;
        }

        $response = wp_remote_get(JZP_TOC_UPDATE_API, [
            'timeout'    => 30,
            'sslverify'  => true,
            'user-agent' => 'WordPress/' . get_bloginfo('version') . '; ' . home_url(),
            'headers'    => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            $this->last_error = 'cURL 错误：' . $response->get_error_message();
            set_transient(JZP_TOC_UPDATE_CACHE_KEY, JZP_TOC_UPDATE_FAIL_FLAG, jzp_toc_get_update_fail_ttl());
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            $this->last_error = '服务器返回 HTTP ' . $code;
            set_transient(JZP_TOC_UPDATE_CACHE_KEY, JZP_TOC_UPDATE_FAIL_FLAG, jzp_toc_get_update_fail_ttl());
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            $this->last_error = '响应内容为空';
            set_transient(JZP_TOC_UPDATE_CACHE_KEY, JZP_TOC_UPDATE_FAIL_FLAG, jzp_toc_get_update_fail_ttl());
            return false;
        }

        // 去掉 BOM 与首尾空白,提升 JSON 兼容性
        $body = preg_replace('/^\xEF\xBB\xBF/', '', $body);
        $body = trim($body);

        $data = json_decode($body);
        if (!is_object($data) || empty($data->version)) {
            $this->last_error = 'JSON 解析失败或缺少 version 字段';
            set_transient(JZP_TOC_UPDATE_CACHE_KEY, JZP_TOC_UPDATE_FAIL_FLAG, jzp_toc_get_update_fail_ttl());
            return false;
        }

        set_transient(JZP_TOC_UPDATE_CACHE_KEY, $data, jzp_toc_get_update_cache_ttl());
        return $data;
    }
}

$GLOBALS['jzp_toc_updater'] = new JZP_TOC_Updater();